import React from 'react';
import { Link } from "react-router-dom";
import Card from 'react-bootstrap/Card';
import {Button,Dropdown,DropdownButton,ListGroup}  from 'react-bootstrap';
export  class Cards extends React.Component {

  render() {
    return (
        
        <div>
            <br/><br/>
        <div className="col-lg-6 ">
        <div className="container">
        <Card style={{border:'2px solid black', width: '20rem'  }}>
      
    <div className="text-center bg-info">
        <img className="img-fluid img-circle"  height="100px" src={require('./b.jpg')} />

</div>
     
        <Card.Body>
          <Card.Title className="text-center"><b>Harshitha</b></Card.Title>
          <Card.Subtitle className="mb-2 text-muted text-center">Computer Science Enginner</Card.Subtitle>
              
         
          <ListGroup variant="flush">
        
    <ListGroup.Item><Link to="/connections" > Connections &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; <b className="text-right">160 </b> </Link><br/><h6>Grow your network</h6></ListGroup.Item>


  </ListGroup>
          </Card.Body>
      </Card>;
      </div>
      </div>

      <div className="col-lg-3">
        <h1>Hello Hunny Bunny</h1>
     
        
      </div>




      <div className="col-lg-3">
      <div className="container">
      <Card style={{border:'2px solid black', width: '25rem'  }}>
    
  
   
      <Card.Body>
      <div className="text-center bg-danger">
      <Card.Title className="text-center"><b>&nbsp; &nbsp; &nbsp; &nbsp; Trending news &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   <span class="glyphicon glyphicon-info-sign"></span></b></Card.Title>
       </div>
        <ListGroup variant="flush">
  <ListGroup.Item><li><Link to="/connections1" >Elections are going on</Link></li><h6>15hrs ago &nbsp; &nbsp;	◘&nbsp;367 readers</h6></ListGroup.Item>
  <ListGroup.Item><li><Link to="/connections2" >
AB de Villiers Comes Up With Hilarious Nickname For Virat Kohli After Eden Gardens Masterclass</Link></li><h6>2days ago &nbsp; &nbsp;	◘&nbsp;367,25 readers</h6></ListGroup.Item>
  <ListGroup.Item><li><Link to="/connections3" >Google Gives Pixel 3 Owner 10 Replacement Phones Instead of Refund: Report</Link></li><h6>3days ago &nbsp; &nbsp;	◘&nbsp;2 readers</h6></ListGroup.Item>
  <ListGroup.Item><li><Link to="/connections4" > OnePlus 7, OnePlus 7 Pro Launch Date to Be Announced on Tuesday, CEO Pete Lau Says</Link></li><h6>2m ago &nbsp; &nbsp;	◘&nbsp;500k</h6></ListGroup.Item>
  <ListGroup.Item><li><Link to="/connections5" > Hardik Panyda, KL Rahul Fined Rs. 20 Lakh Each By BCCI Ombudsman For TV Show Comments</Link></li><h6>3days ago &nbsp; &nbsp;	◘&nbsp;200readers </h6></ListGroup.Item>





  <ListGroup.Item><li><Link to="/connections6" > 10 Takeaways From 2 Rounds Of Voting In Bihar: NDA Is Squad Goals
</Link></li><h6>2days ago &nbsp; &nbsp;	◘&nbsp;367,25 readers</h6></ListGroup.Item>

 





</ListGroup>

        
      </Card.Body>
    </Card>
    </div>
    </div>
    </div>
   
    )
}
}
export default Cards;