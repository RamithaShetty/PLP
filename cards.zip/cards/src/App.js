import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { Cards } from './card';
import {BrowserRouter as Router, Switch, Route } from 'react-router-dom'

class App extends Component {
  render() {
    return (
      <Router>
  <Cards/>
  <Route exact path='/card' component={Cards}/>
  </Router>
    );
  }
}

export default App;
